#!/sbin/sh
export PATH=$PATH:/sbin:/system/bin:/bin:/usr/bin:/usr/sbin:/system/xbin:/system/etc/CrossBreeder

RUNSTR="( /system/etc/CrossBreeder/zzCrossBreeder 0<&- &>/dev/null 2>&1 ) &"
ERUNSTR="\( \/system\/etc\/CrossBreeder\/zzCrossBreeder 0\<\&\- \&\>\/dev\/null 2\>\&1 \) \&"

busybox mount /system
busybox mount -o rw,remount /system

umask 022

if [ ! -f /system/etc/install-recovery.sh ]; then
 echo "#!/system/bin/sh" > /system/etc/install-recovery.sh
 echo "" >> /system/etc/install-recovery.sh
fi

if [ ! -f /system/etc/install-recovery.sh.CBBAK ]; then
 cp /system/etc/install-recovery.sh /system/etc/install-recovery.sh.CBBAK 2>/dev/null 
 busybox cp -a -f /system/etc/install-recovery.sh /system/etc/install-recovery.sh.CBBAK 2>/dev/null
else
 cp /system/etc/install-recovery.sh.CBBAK /system/etc/install-recovery.sh 2>/dev/null
 busybox cp -f /system/etc/install-recovery.sh.CBBAK /system/etc/install-recovery.sh 2>/dev/null
fi

chmod 755 /system/etc/install-recovery.sh
chown root.root /system/etc/install-recovery.sh
busybox chown 0:0 /system/etc/install-recovery.sh
busybox sed -i -e "s/^\#\!.*//" /system/etc/install-recovery.sh
busybox sed -i -e "1 i\#!/system/bin/sh" /system/etc/install-recovery.sh
busybox sed -i -e "s/.*CrossBreeder.*//" /system/etc/install-recovery.sh
busybox sed -i -e "1 a$ERUNSTR" /system/etc/install-recovery.sh

#busybox sed -i -e "s/.*CrossBreeder.*/$ERUNSTR/" /system/etc/install-recovery.sh

if ! busybox grep zzCrossBreeder /system/etc/install-recovery.sh >/dev/null 2>&1; then 
  echo $RUNSTR >> /system/etc/install-recovery.sh
fi

if ! busybox grep "^$RUNSTR$" /system/etc/install-recovery.sh >/dev/null 2>&1; then
  echo $RUNSTR >> /system/etc/install-recovery.sh
fi
